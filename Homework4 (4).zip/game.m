% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

clear; clc; 

playAgain = "y";

while lower(playAgain) == "y"

    fprintf("Let's play Tic-Tac-Toe!\n")
    
    board = newboard();
    
    turnNum = 0;
    
    while checkwinner(board) == 'N'
        
        if mod(turnNum, 2) == 0
            fprintf("Player X's turn\n")
        else
            fprintf("Player's O's turn\n")
        end
    
        displayboard(board);
    
        rowNum = input("Select a row: ");
        while rowNum ~= 1 && rowNum ~= 2 && rowNum ~= 3
            fprintf("Invalid row selection!\n")
            rowNum = input("Select a row: ");
        end
    
        colNum = input("Select a column: ");
        while colNum ~= 1 && colNum ~= 2 && colNum ~= 3
            fprintf("Invalid column selection!\n")
            colNum = input("Select a column: ");
        end
    
        while isvalidmove(board, [rowNum, colNum]) == false
            fprintf("That selection is invalid!\n")
    
            rowNum = input("Select a row: ");
            while rowNum ~= 1 && rowNum ~= 2 && rowNum ~= 3
                fprintf("Invalid row selection!\n")
                rowNum = input("Select a row: ");
            end
    
            colNum = input("Select a column: ");
            while colNum ~= 1 && colNum ~= 2 && colNum ~= 3
                fprintf("Invalid column selection!\n")
                colNum = input("Select a column: ");
            end
        end
        
        if mod(turnNum, 2) == 0
            board = changeboard(board, [rowNum, colNum], 'X');
        else
            board = changeboard(board, [rowNum, colNum], 'O');
        end
    
        turnNum = turnNum + 1;
    end

    displayboard(board);

    if checkwinner(board) == 'X'
        fprintf("Player X WINS!\n")
    elseif checkwinner(board) == 'O'
        fprintf("Player O WINS!\n")
    elseif checkwinner(board) == 'S'
        fprintf("Stalemate reached\n")
    end
    
    playAgain = input("Would you like to play again? (y/n): ", "s");

end
    



