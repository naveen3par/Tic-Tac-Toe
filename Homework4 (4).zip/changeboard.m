% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

function [newBoard] = changeboard(currentBoard, position, character)
%CHANGEBOARD: Changes the board by adding a new character to a chosen
%position
%   Changes 0 at chosen position to 1 if 'X' or 2 if 'Y'

if nargin ~= 3
    error("ITP168:nargin", "Must provide 3 inputs")
end 

notNum = 0;
not012 = 0;
for index1 = 1:3
    for index2 = 1:3
        if ~isnumeric(currentBoard(index1, index2)) 
            notNum = notNum + 1;
        end
        if currentBoard(index1, index2) ~= 0 && currentBoard(index1, index2) ~= 1 && currentBoard(index1, index2) ~= 2
            not012 = not012 + 1;
        end
    end
end
if size(currentBoard, 1) ~= 3 || size(currentBoard, 2) ~= 3 || notNum ~= 0 || not012 ~= 0
    error("ITP168:input", "Input must be a 3x3 array that only contains 0's, 1's, and 2's")
end

notNum = 0;
not123 = 0;
for index = 1:2
    if ~isnumeric(position(1, index)) 
        notNum = notNum + 1;
    end
    if position(index) ~= 1 && position(index) ~= 2 && position(index) ~= 3
        not123 = not123 + 1;
    end
end
if size(position, 1) ~= 1 || size(position, 2) ~= 2 || notNum ~= 0 || not123 ~= 0
    error("ITP168:input", "Inputted position must have 2 elements - row number and column number of 3x3 array");
end

if ~ischar(character) || size(character, 1) ~= 1 || size(character, 2) ~= 1
    error("ITP168:input", "Inputted character must be either an X or O");
end
if character ~= 'X' && character ~= 'O'
    error("ITP168:input", "Inputted character must be either an X or O");
end

if character == 'X'
    currentBoard(position(1), position(2)) = 1;
elseif character == 'O'
    currentBoard(position(1), position(2)) = 2;
end

newBoard = currentBoard;

end

