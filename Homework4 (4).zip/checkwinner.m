% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

function [winnerCharacter] = checkwinner(currentBoard)
%CHECKWINNER: Checks if there is a winner
%   Checks if a row, column, or diagonal have the same numerical value

winnerCharacter = 'N';

if nargin ~= 1
    error("ITP168:nargin", "Must provide only 1 input")
end 

notNum = 0;
not012 = 0;
for index1 = 1:3
    for index2 = 1:3
        if ~isnumeric(currentBoard(index1, index2)) 
            notNum = notNum + 1;
        end
        if currentBoard(index1, index2) ~= 0 && currentBoard(index1, index2) ~= 1 && currentBoard(index1, index2) ~= 2
            not012 = not012 + 1;
        end
    end
end
if size(currentBoard, 1) ~= 3 || size(currentBoard, 2) ~= 3 || notNum ~= 0 || not012 ~= 0
    error("ITP168:input", "Input must be a 3x3 array that only contains 0's, 1's, and 2's")
end

for dim = 1:3
     if currentBoard(dim, :) == 1
        winnerCharacter = 'X';
     elseif currentBoard(:, dim) == 1
        winnerCharacter = 'X';
     end

     if currentBoard(dim, :) == 2
        winnerCharacter = 'O';
     elseif currentBoard(:, dim) == 2
        winnerCharacter = 'O';
     end
end

if currentBoard(1,1) == 1 && currentBoard(2,2) == 1 && currentBoard(3,3) == 1
    winnerCharacter = 'X';
elseif currentBoard(1,1) == 2 && currentBoard(2,2) == 2 && currentBoard(3,3) == 2
    winnerCharacter = 'O';
elseif currentBoard(1,3) == 1 && currentBoard(2, 2) == 1 && currentBoard(3,1) == 1
    winnerCharacter = 'X';
elseif currentBoard(1,3) == 2 && currentBoard(2, 2) == 2 && currentBoard(3,1) == 2
    winnerCharacter = 'O';
end

occupiedSpaces = 0;
for index1 = 1:3
    for index2 = 1:3
        if currentBoard(index1, index2) ~= 0
            occupiedSpaces = occupiedSpaces + 1;
        end
    end
end

if winnerCharacter ~= 'X' && winnerCharacter ~= 'O' && occupiedSpaces == 9
    winnerCharacter = 'S';
elseif winnerCharacter ~= 'X' && winnerCharacter ~= 'O' && occupiedSpaces ~= 9
    winnerCharacter = 'N';
end 

end

