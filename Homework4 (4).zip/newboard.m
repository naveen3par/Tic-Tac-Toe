% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

function [blankBoard] = newboard()
% NEWBOARD: Creates a new board
%   Returns a blank 3 x 3 array with zeroes in each position

blankBoard = [0, 0, 0; 0, 0, 0; 0, 0, 0];
end

