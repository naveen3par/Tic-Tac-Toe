% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

function [] = displayboard(inputArray)
%DISPLAYBOARD: Prints numeric board with X's and O's
%   Checks inputted board of numbers and prints out corresponding
%   characters in a gridlike fashion

if nargin ~= 1
    error("ITP168:nargin", "Must only provide 1 input")
end 

notNum = 0;
not012 = 0;
for index1 = 1:3
    for index2 = 1:3
        if ~isnumeric(inputArray(index1, index2)) 
            notNum = notNum + 1;
        end
        if inputArray(index1, index2) ~= 0 && inputArray(index1, index2) ~= 1 && inputArray(index1, index2) ~= 2
            not012 = not012 + 1;
        end
    end
end
if size(inputArray, 1) ~= 3 || size(inputArray, 2) ~= 3 || notNum ~= 0 || not012 ~= 0
    error("ITP168:input", "Input must be a 3x3 array that only contains 0's, 1's, and 2's")
end

for index1 = 1:3
    for index2 = 1:3
        if inputArray(index1, index2) == 0
            fprintf("_")
        elseif inputArray(index1, index2) == 1
            fprintf("X")
        elseif inputArray(index1, index2) == 2
            fprintf("O")
        end
        if index2 == 3 && index1 ~= 3
            fprintf("\n---------\n")
        elseif index1 == 3 && index2 == 3
            fprintf(" \n")
        else
            fprintf(" | ")
        end
    end
end

end

