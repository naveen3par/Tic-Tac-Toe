% Naveen Paramasivan
% ITP 168 Spring 2023
% Homework 4
% paramasi@usc.edu

function [valid] = isvalidmove(board,position)
%ISVALIDMOVE: Checks if inputted move is valid
%   Checks if position on board is already occupied by a previous turn or
%   not

if nargin ~= 2
    error("ITP168:nargin", "Must provide 2 inputs")
end 

notNum = 0;
not012 = 0;
for index1 = 1:3
    for index2 = 1:3
        if ~isnumeric(board(index1, index2)) 
            notNum = notNum + 1;
        end
        if board(index1, index2) ~= 0 && board(index1, index2) ~= 1 && board(index1, index2) ~= 2
            not012 = not012 + 1;
        end
    end
end
if size(board, 1) ~= 3 || size(board, 2) ~= 3 || notNum ~= 0 || not012 ~= 0
    error("ITP168:input", "Input must be a 3x3 array that only contains 0's, 1's, and 2's")
end

notNum = 0;
not123 = 0;
for index = 1:2
    if ~isnumeric(position(1, index)) 
       notNum = notNum + 1;
    end
    if position(index) ~= 1 && position(index) ~= 2 && position(index) ~= 3
        not123 = not123 + 1;
    end
end
if size(position, 1) ~= 1 || size(position, 2) ~= 2 || notNum ~= 0 || not123 ~= 0
    error("ITP168:input", "Inputted position must have 2 elements - row number and column number of 3x3 array");
end

if board(position(1), position(2)) == 0
    valid = true;
else
    valid = false;
end

end

